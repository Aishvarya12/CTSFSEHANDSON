package com.cognizant.ormtool;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrmToolApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrmToolApplication.class, args);
	}

}
